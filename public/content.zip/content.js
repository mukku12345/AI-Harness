//Inputs with icon Code
const inputs = document.querySelectorAll('input[type="text"], input[type="password"], textarea,input[type="email"]');
inputs.forEach(input => {
  const icon = document.createElement('img');
  icon.className = 'icon';
  icon.src = 'https://picsum.photos/200';
  icon.style.width = '16px';
  icon.style.height = '16px';
  icon.style.position = 'absolute';
  icon.style.top = '50%';
  icon.style.right = '10px';
  icon.style.transform = 'translateY(-50%)';
  icon.addEventListener('click', () => {
    console.log("clicked")
    const inputPosition = input.getBoundingClientRect();
    const windowX = window.screenX;
    const windowY = window.screenY;
    const x = windowX + inputPosition.left;
    const y = windowY + inputPosition.top;
    console.log(x);
    console.log("top", y)
    // window.open('https://loving-jemison.62-151-180-40.plesk.page/', '', `left=${x}, top=${y}, width=300, height=200`);
    // chrome.runtime.sendMessage({ action: "openMetamask" });

    // chrome.runtime.sendMessage({
    //   action: 'openExtension',
    //   text: selectedText,
    //   x: x,
    //   y: y,
    // });

    var myDiv1 = document.createElement('div');
    myDiv1.id = 'myDiv1';
    myDiv1.className = 'myDivClass';
    myDiv1.style.backgroundColor = '#f5f5f5';
    myDiv1.style.border = '1px solid #ccc';
    myDiv1.style.position = 'absolute';
    myDiv1.style.top = y + 25 + 'px';
    myDiv1.style.left = x + 'px';

    var parentElement = document.body; // replace this with the actual parent element
    parentElement.appendChild(myDiv1);

    var iframe = document.createElement('iframe');
    iframe.src = 'https://loving-jemison.62-151-180-40.plesk.page/';
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    // iframe.style.left=x + "px";
    // iframe.style.top=y+"px"
    myDiv1.appendChild(iframe);
    document.body.appendChild(myDiv1);
 

  });
  input.parentNode.appendChild(icon);
});
//remove input div




///text selection code
document.addEventListener('mouseup', (event) => {
  const selectedText = window.getSelection().toString();

  if (selectedText) {
    var myDiv = document.createElement('div');
    myDiv.id = 'myDiv';
    myDiv.className = 'myDivClass';
    myDiv.style.backgroundColor = '#f5f5f5';
    myDiv.style.border = '1px solid #ccc';
    myDiv.style.position = 'absolute';

    var parentElement = document.body; // replace this with the actual parent element
    parentElement.appendChild(myDiv);

    var iframe = document.createElement('iframe');
    iframe.src = 'https://loving-jemison.62-151-180-40.plesk.page/';
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    // iframe.style.left=x + "px";
    // iframe.style.top=y+"px"
    myDiv.appendChild(iframe);
    // Get the position of the selected text
    var range = window.getSelection().getRangeAt(0);
    var rect = range.getBoundingClientRect();

    myDiv.style.top = rect.top + window.pageYOffset + 30 + 'px';
    myDiv.style.left = rect.left + window.pageXOffset + 'px';

    // Add the div to the page
    document.body.appendChild(myDiv);
  }
  document.addEventListener('selectionchange', function () {
    var myDiv = document.getElementById('myDiv');
    if (!window.getSelection().toString().trim() && myDiv) {
      myDiv.parentNode.removeChild(myDiv);
    }
  });
});



//Side Right Icon
// create icon element
const iconDiv = document.createElement('div');
iconDiv.id = 'my-icon';
iconDiv.textContent = 'Click me';

// add icon to the right side of the page
iconDiv.style.position = 'fixed';
iconDiv.style.top = '50%';
iconDiv.style.right = '50px';
iconDiv.style.transform = 'translateY(-50%)';
iconDiv.style.backgroundColor = 'gray';
iconDiv.style.zIndex = '9999';
document.body.appendChild(iconDiv);

// create div and iframe elements
const myDiv2 = document.createElement('div');
myDiv2.className = 'myDivClass2';
myDiv2.id = 'myDivid2';

const myIframe = document.createElement('iframe');

// set attributes for div and iframe
myDiv2.style.position = 'fixed';
myDiv2.style.top = '0%';
myDiv2.style.right = '120px';
myDiv2.style.width = '400px';
myDiv2.style.height = '300px';
myDiv2.style.backgroundColor = 'white';
myDiv2.style.border = '1px solid black';
myDiv2.style.zIndex = '9999';
myDiv2.style.display = 'none';

myIframe.src = 'https://loving-jemison.62-151-180-40.plesk.page/';
myIframe.style.width = '100%';
myIframe.style.height = '100%';

// add click event listener to icon element
iconDiv.addEventListener('click', function () {
  // add iframe to div
  myDiv2.appendChild(myIframe);

  // add div to the right side of the icon
  const iconRect = iconDiv.getBoundingClientRect();
  // myDiv2.style.top = `${iconRect.top}px`;
  // myDiv2.style.left = `${iconRect.left + 10}px`;
  myDiv2.style.left = '820px';

  myDiv2.style.display = 'block';

  // add click event listener to hide the div when user clicks outside of it
});

// add div to the page
document.body.appendChild(myDiv2);

window.onclick = e => {
  console.log("event", e)
  if (!myDiv2.contains(e.target) && e.target !== iconDiv) {
    myDiv2.style.display = 'none';
  }

}

document.addEventListener('mouseup', function(e) {
  var container = document.getElementById('myDiv1');
  if (!container.contains(e.target)) {
    console.log("display none")
      container.style.display = 'none';
  }
});

// window.onclick = e => {
//   console.log("event in ", e)
//   if (!myDiv1) {
//     myDiv1.style.display = 'none';
//     console.log('now remove div1')
//   }

//   // var textRemove = document.getElementById("tutorial");
//   // textRemove.remove();
// }